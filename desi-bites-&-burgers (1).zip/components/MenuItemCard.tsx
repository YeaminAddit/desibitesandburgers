
import React from 'react';
import { FoodItem } from '../types';

interface MenuItemCardProps {
  item: FoodItem;
}

export const MenuItemCard: React.FC<MenuItemCardProps> = ({ item }) => {
  const handleOrderClick = () => {
    alert(`You selected ${item.name} for order! (This is a demo)`);
  };

  return (
    <div className="bg-brand-surface rounded-xl shadow-card hover:shadow-card-hover transition-shadow duration-300 overflow-hidden flex flex-col">
      <div className="aspect-[16/9] w-full"> {/* Modern Tailwind aspect ratio */}
        <img 
          src={item.imageUrl} 
          alt={item.name} 
          className="w-full h-full object-cover" 
        />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <h4 className="text-xl font-heading font-semibold text-brand-primary mb-2">{item.name}</h4>
        <p className="text-brand-text-secondary text-sm mb-4 flex-grow">{item.description}</p>
        <div className="flex justify-between items-center mt-auto">
          <p className="text-lg font-heading font-bold text-brand-accent">{item.price}</p>
          <button 
            onClick={handleOrderClick}
            className="bg-brand-secondary text-brand-text-light hover:bg-gray-700 px-4 py-2 rounded-md text-sm font-medium transition-colors duration-300"
            aria-label={`Order ${item.name}`}
          >
            Order Now
          </button>
        </div>
      </div>
    </div>
  );
};