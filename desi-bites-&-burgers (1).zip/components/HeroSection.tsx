
import React from 'react';

export const HeroSection: React.FC = () => {
  const handleExploreMenuClick = (event: React.MouseEvent<HTMLAnchorElement>) => {
    event.preventDefault();
    const element = document.getElementById('menu'); // Target ID is 'menu'
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="bg-hero-pattern bg-cover bg-center text-brand-text-light relative">
      <div className="absolute inset-0 bg-black opacity-50"></div> {/* Overlay for text readability */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-32 md:py-48 relative z-10">
        <div className="text-center">
          <h1 className="text-5xl md:text-7xl font-heading font-extrabold mb-6">
            Authentic Flavors, Modern Twist
          </h1>
          <p className="text-xl md:text-2xl font-body mb-10 max-w-3xl mx-auto">
            Experience the vibrant taste of Bangladeshi street food and savor our juicy halal smash burgers. Quality ingredients, unforgettable taste.
          </p>
          <div>
            <a
              href="#menu"
              onClick={handleExploreMenuClick}
              className="bg-brand-primary hover:bg-red-700 text-white font-bold py-4 px-10 rounded-lg text-lg font-heading transition-transform duration-300 ease-in-out transform hover:scale-105 shadow-lg"
            >
              Explore Our Menu
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
