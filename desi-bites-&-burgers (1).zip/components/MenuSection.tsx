
import React from 'react';
import { MENU_ITEMS } from '../constants';
import { FoodCategory } from '../types';
import { CategorySection } from './CategorySection';

export const MenuSection: React.FC = () => {
  const categories = Object.values(FoodCategory);
  
  return (
    <section id="menu" className="py-16 lg:py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-heading font-bold text-brand-primary">
            Discover Our Menu
          </h2>
          <p className="mt-4 text-lg text-brand-text-secondary max-w-2xl mx-auto">
            A curated selection of our finest dishes, crafted with passion and the freshest ingredients.
          </p>
        </div>
        
        {categories.map((category) => {
          const itemsInCategory = MENU_ITEMS.filter(item => item.category === category);
          if (itemsInCategory.length === 0) return null;
          
          return (
            <CategorySection 
              key={category} 
              categoryName={category} 
              items={itemsInCategory} 
            />
          );
        })}
      </div>
    </section>
  );
};
