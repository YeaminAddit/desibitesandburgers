
import React from 'react';
import { FoodItem } from '../types';
import { MenuItemCard } from './MenuItemCard';

interface CategorySectionProps {
  categoryName: string;
  items: FoodItem[];
}

export const CategorySection: React.FC<CategorySectionProps> = ({ categoryName, items }) => {
  return (
    <div className="mb-16 last:mb-0">
      <h3 className="text-3xl font-heading font-semibold text-brand-secondary mb-8 pb-3 border-b-2 border-brand-accent">
        {categoryName}
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {items.map(item => (
          <MenuItemCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
};
