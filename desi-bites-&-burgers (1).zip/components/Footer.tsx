
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-secondary text-brand-text-light py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-4">
          {/* Placeholder for social media icons */}
          <div className="flex justify-center space-x-6">
            <a href="#" className="hover:text-brand-accent transition-colors duration-300" aria-label="Facebook">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                {/* Basic Facebook Icon Path */}
                <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
              </svg>
            </a>
            <a href="#" className="hover:text-brand-accent transition-colors duration-300" aria-label="Instagram">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                {/* Basic Instagram Icon Path */}
                <path fillRule="evenodd" d="M12 2C8.74 2 8.333.015 7.053.006A4.75 4.75 0 002.298 4.748C2.016 6.027 2 6.433 2 9.255v5.49c0 2.822.015 3.228.006 4.508A4.75 4.75 0 004.748 21.7c1.279.282 1.685.29 4.507.29h5.49c2.822 0 3.228-.015 4.508-.006a4.75 4.75 0 004.748-4.752c.282-1.279.29-1.685.29-4.507v-5.49c0-2.822-.015-3.228-.006-4.508A4.75 4.75 0 0019.252 2.3C17.973 2.016 17.567 2 14.745 2H9.255zm0 4.688a5.062 5.062 0 100 10.124 5.062 5.062 0 000-10.124zM12 15a3.25 3.25 0 110-6.5 3.25 3.25 0 010 6.5zm6.042-8.328a1.313 1.313 0 100-2.626 1.313 1.313 0 000 2.626z" clipRule="evenodd" />
              </svg>
            </a>
            <a href="#" className="hover:text-brand-accent transition-colors duration-300" aria-label="Twitter">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                {/* Basic Twitter Icon Path */}
                <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
              </svg>
            </a>
          </div>
        </div>
        <p className="text-sm">
          &copy; {new Date().getFullYear()} Desi Bites & Burgers. All Rights Reserved.
        </p>
        <p className="text-xs mt-2">
          Website made by Yeamin
        </p>
      </div>
    </footer>
  );
};