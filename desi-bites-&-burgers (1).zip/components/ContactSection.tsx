
import React from 'react';

export const ContactSection: React.FC = () => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    alert("Thank you for your message! We'll get back to you soon. (This is a demo)");
    // In a real app, you would handle form submission here
  };

  return (
    <section id="contact" className="py-16 lg:py-24 bg-brand-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-heading font-bold text-brand-primary">
            Get In Touch
          </h2>
          <p className="mt-4 text-lg text-brand-text-secondary max-w-2xl mx-auto">
            We'd love to hear from you! Whether it's for reservations, feedback, or just to say hello.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div className="bg-brand-surface p-8 rounded-lg shadow-card">
            <h3 className="text-2xl font-heading font-semibold text-brand-secondary mb-6">Contact Information</h3>
            <div className="space-y-4 text-brand-text-secondary">
              <p><strong>Address:</strong> 123 Foodie Lane, Flavor Town, FT 45678</p>
              <p><strong>Phone:</strong> (555) 123-4567</p>
              <p><strong>Email:</strong> info@desibitesburgers.com</p>
              <p><strong>Hours:</strong> Mon - Sun: 11:00 AM - 10:00 PM</p>
            </div>
            <div className="mt-6">
              {/* Placeholder for a map */}
              <div className="w-full h-64 bg-gray-300 rounded-md flex items-center justify-center text-gray-500">
                [Embedded Map Placeholder]
              </div>
            </div>
          </div>

          <div className="bg-brand-surface p-8 rounded-lg shadow-card">
            <h3 className="text-2xl font-heading font-semibold text-brand-secondary mb-6">Send Us a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-brand-text-secondary">Full Name</label>
                <input type="text" name="name" id="name" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm" />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-brand-text-secondary">Email Address</label>
                <input type="email" name="email" id="email" required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm" />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-brand-text-secondary">Message</label>
                <textarea name="message" id="message" rows={4} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent sm:text-sm"></textarea>
              </div>
              <div>
                <button 
                  type="submit" 
                  className="w-full bg-brand-primary hover:bg-red-700 text-white font-bold py-3 px-4 rounded-md transition-colors duration-300 text-lg font-heading"
                >
                  Send Message
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
