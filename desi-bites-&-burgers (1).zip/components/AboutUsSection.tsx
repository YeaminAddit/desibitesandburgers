
import React from 'react';

export const AboutUsSection: React.FC = () => {
  return (
    <section id="about" className="py-16 lg:py-24 bg-brand-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-heading font-bold text-brand-primary">
            Our Story
          </h2>
          <p className="mt-4 text-lg text-brand-text-secondary max-w-2xl mx-auto">
            More Than Just Food, It's a Passion
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=600&q=80" 
              alt="Warm and inviting restaurant interior" 
              className="rounded-lg shadow-card w-full h-auto object-cover"
            />
          </div>
          <div className="text-brand-text-secondary space-y-6 text-lg">
            <p>
              Welcome to Desi Bites & Burgers, where traditional Bangladeshi flavors meet contemporary culinary techniques. 
              Our journey began with a simple dream: to share the authentic tastes of our homeland and the universal joy of a perfectly crafted burger with our community.
            </p>
            <p>
              We pride ourselves on using only the freshest halal ingredients, sourced locally whenever possible. 
              From the bustling streets of Dhaka to your plate, every dish, whether it's our signature Fuchka, aromatic Chaa, or a mouth-watering Smash Burger, 
              is prepared with love, care, and a deep respect for culinary traditions.
            </p>
            <p>
              Join us for an unforgettable dining experience that tantalizes your taste buds and warms your soul.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};